﻿using System;

namespace ConsoleApp2
{
    class Program
    {
        public static int aikayksikkö = 0;
        static void Main(string[] args)
        {
            string vastaus = "";
            bool valo = true;
            Console.WriteLine("Heräät lattialta hämärästä ankeasta ikkunattomasta huoneesta");
            Console.ReadKey();
            Console.WriteLine("Huoneen kulmassa vanha öljylamppu palaa himmeänä ja toisessa kulmassa reppu lojuu lattialla. Huoneen ainoa ovi on raollaan. ");
            Console.ReadKey();
            Console.WriteLine("Tajuat ettet muista miten tänne päädyit tai mikä paikka tämä on");
            Console.ReadKey();
            Console.WriteLine("Mitä teet? 1: Menet ovesta ulos 2: Otat öljylampun 3: Avaat repun 4: Otat repun selkääsi");
            vastaus = ReadLine();

        }
        static string ReadLine()
        {
            aikayksikkö++;
            Console.WriteLine();
            return Console.ReadLine();
        }
    }
}
