#import sys
#if(sys.argv[1] == "emu"):
#    from sense_emu import SenseHat
#else:
from sense_hat import SenseHat
import random
import time
sense = SenseHat()
import math

class Tile:
    def __init__(self, x2, y2):
        self.x = x2
        self.y = y2
        self.mine = False
        self.AdjecentMines = 0
        self.vari = [50, 50, 50]
        self.status = "hidden"

def teelauta(Laudankoko):
    board = []
    for x in range(Laudankoko): 
        row = []
        for y in range(Laudankoko):
            tile = Tile(x, y)
            row.append(tile)
        board.append(row)
    return board


BOARD_SIZE = 8
NUMBER_OF_MINES = 10
board = teelauta(BOARD_SIZE)
#markedMines = 0
hiddenTiles = BOARD_SIZE*BOARD_SIZE
GeneratingMines = 0
game = False
gameEnded = False

cursor = [3, 3]

def getMinePositions(LaudanKoko, MiinojenMaara, TileX, TileY):
    #console.log(TileX, TileY, "hfd")
    positions = []
    while (len(positions) < MiinojenMaara):
        XXYY = randomNumber(LaudanKoko, TileX, TileY, [True, True], positions)
        position = {
            "x": XXYY[0],
            "y": XXYY[1]
        }

        if not any(Position_Match(p, position) for p in positions):
            positions.append(position)
        
    print(positions)
    return positions

def Position_Match(a, b) :
    return (a["x"] == b["x"] and a["y"] == b["y"])

def Position_Match2(a, b) :
    return (a["x"] == b[0] and a["y"] == b[1])

kolmesti = 0
kertaa = 0
def randomNumber(size, TileX, TileY, XXjaYY, positionsT):
    global kertaa
    global kolmesti
    global BOARD_SIZE, board
    kertaa+= 1
    #XX = XXjaYY[0]
    #YY = XXjaYY[1]
    XX = math.floor(random.random() * size)
    YY = math.floor(random.random() * size)
    while (YY == TileY - 1 or YY == TileY or YY == TileY + 1) and (XX == TileX - 1 or XX == TileX or XX == TileX + 1):
        XX = math.floor(random.random() * size)
        YY = math.floor(random.random() * size)

    loputPaikat = [positionsT]
    if((len(positionsT) > 110) and (kolmesti == 3)) :
        for x in range(5) :                
            for y in range(5) :
                position = {
                    x: TileX-2+x,
                    y: TileY-2+y
                }
                loputPaikat.append(position)
                
        for x in range(BOARD_SIZE) :
            for y in range(BOARD_SIZE) :
                if not any(Position_Match(p, [x, y]) for p in loputPaikat):
                    print(kertaa, "k", [x, y])
                    return [x, y]

        print(positionsT)
        x = 0
        y = 0
        for row in board:
            for tile in row:
                x = tile.x
                y = tile.y
                if any(Position_Match(p, [x, y]) for p in positionsT) :
                    tile.mine = True
                else:
                    tile.mine = False
                    #tile.mine = positionsT.some(Position_Match.bind(null, {x, y}))
        LOSE()
        print(board)
        return
    if((YY > TileY - 3 and YY < TileY + 3) and (XX > TileX - 3 and XX < TileX + 3)) :
        if(kolmesti < 3 and (not any(Position_Match2(p, [XX, YY]) for p in positionsT))) :
            print(kolmesti, "kolmesti", XX, YY)
            kolmesti+= 1
            return [XX, YY]
            
        else:
            while((YY > TileY - 3 and YY < TileY + 3) and (XX > TileX - 3 and XX < TileX + 3)) :
                XX = math.floor(random.random() * size)
                YY = math.floor(random.random() * size)
            print(kertaa, "q")
            return [XX, YY]
    return [XX, YY]

def GenerateMines(TileX, TileY) :
    global BOARD_SIZE, board, NUMBER_OF_MINES
    minePositions = getMinePositions(BOARD_SIZE, NUMBER_OF_MINES, TileX, TileY)
    print(minePositions)
    x = 0
    y = 0
    for row in board :
        for tile in row :
            x = tile.x
            y = tile.y
            #if not any(Position_Match(p, position) for p in positions):
            #positions.append(position)
            if any(Position_Match2(p, [x, y]) for p in minePositions) :
                tile.mine = True
            else:
                tile.mine = False
            print()
    ShowAdjecentTiles(TileX, TileY)

def ShowAllMines() :
    global BOARD_SIZE, board, NUMBER_OF_MINES
    for row in board :
        for tile in row :
            if (tile.mine == True) :
                tile.status = "mine"
                sense.set_pixel(tile.x, tile.y, [255, 0, 0])


def NumberOfMinesTouchingTile(TileX, TileY, tile) :
    global game
    global BOARD_SIZE, board, NUMBER_OF_MINES, GeneratingMines, hiddenTiles
    MinesTouching = 0
    if (game != True) :
        if (GeneratingMines == 0) :
            game = True
            tile.set_status = "number"
            tile.AdjecentMines = 0
            print(hiddenTiles)
            hiddenTiles-= 1
            GeneratingMines = 1
            GenerateMines(TileX, TileY)
            return
        
        return
    
    if (tile.mine == True) :
        LOSE()
        return
    
    if (tile.status != "number") :
        tile.status = ("number")
        hiddenTiles-= 1
        #console.log(hiddenTiles)
    if (hiddenTiles == NUMBER_OF_MINES) :
        WIN()

    for y in range(3) :
        for x in range (3):
            if (y + TileY - 1 > -1 and x + TileX - 1 > -1 and y + TileY - 1 < BOARD_SIZE and x + TileX - 1 < BOARD_SIZE) :
                if (board[x + TileX - 1][y + TileY - 1].mine) :
                    MinesTouching+= 1

    tile.AdjecentMines = MinesTouching
    if (MinesTouching == 0) :
        ShowAdjecentTiles(TileX, TileY)
        print("jihuu")


def ShowAdjecentTiles(TileX, TileY) :
    global BOARD_SIZE, board, NUMBER_OF_MINES
    for y in range(3):
        for x in range(3):
            if (y + TileY - 1> -1 and x + TileX -1 > -1 and y + TileY - 1 < BOARD_SIZE and x + TileX - 1 < BOARD_SIZE) :
                if ((x + TileX - 1 == TileX and y + TileY - 1 == TileY) or board[x + TileX - 1][y + TileY - 1].status == "number") :
                    turha = 0
                else: 
                    NumberOfMinesTouchingTile(x + TileX - 1, y + TileY - 1, board[x + TileX - 1][y + TileY - 1]) 

def isDashingPossible(AdjecentMines, TileX, TileY) :
    global BOARD_SIZE, board, NUMBER_OF_MINES
    MarkedTouching = 0
    for y in range(3):
        for x in range(3):
            if (y + TileY - 1 > -1 and x + TileX - 1 > -1 and y + TileY - 1 < BOARD_SIZE and x + TileX - 1 < BOARD_SIZE) :
                if (board[x + TileX - 1][y + TileY - 1].status == "marked") :
                    MarkedTouching+= 1

    print(MarkedTouching, AdjecentMines)
    if (MarkedTouching == AdjecentMines) :
        return True
    else: 
        return False


def Dashing(TileX, TileY) :
    global BOARD_SIZE, board, NUMBER_OF_MINES
    for y in range(3):
        for x in range(3):
            if (y + TileY - 1 > -1 and x + TileX - 1 > -1 and y + TileY - 1 < BOARD_SIZE and x + TileX - 1 < BOARD_SIZE) :
                if (x + TileX - 1 == TileX and y + TileY - 1 == TileY or board[x + TileX - 1][y + TileY - 1].status == "number" or board[x + TileX - 1][y + TileY - 1].status == "marked") :
                    continue
                else:
                    NumberOfMinesTouchingTile(x + TileX - 1, y + TileY - 1, board[x + TileX - 1][y + TileY - 1]) 


def WIN() :
    global game, gameEnded
    game = False
    gameEnded = True
    print("Voitit")

def LOSE() :
    global game, gameEnded
    game = False
    gameEnded = True
    ShowAllMines()
    print("Hävisit")

HeldMid = False

def AllScreenUpdate():
    global BOARD_SIZE, board, NUMBER_OF_MINES, cursor, HeldMid, sense
    #sense.clear()
    for row in board:
        for tile in row:
            if(tile.status == "number"):
                if(tile.AdjecentMines == 0):
                    sense.set_pixel(tile.x, tile.y, [205, 205, 205])
                    tile.vari = [205, 205, 205]
                    continue
                if(tile.AdjecentMines == 1):
                    sense.set_pixel(tile.x, tile.y, [205, 205, 0])
                    tile.vari = [205, 205, 0]
                    continue
                if(tile.AdjecentMines == 2):
                    sense.set_pixel(tile.x, tile.y, [205, 115, 0])
                    tile.vari = [205, 115, 0]
                    continue
                if(tile.AdjecentMines == 3):
                    sense.set_pixel(tile.x, tile.y, [205, 0, 0])
                    tile.vari = [205, 0, 0]
                    continue
                if(tile.AdjecentMines == 4):
                    sense.set_pixel(tile.x, tile.y, [205, 0, 205])
                    tile.vari = [205, 0, 205]
                    continue
                if(tile.AdjecentMines == 5):
                    sense.set_pixel(tile.x, tile.y, [75, 0, 130])
                    tile.vari = [75, 0, 130]
                    continue
                if(tile.AdjecentMines == 6):
                    sense.set_pixel(tile.x, tile.y, [0, 0, 205])
                    tile.vari = [0, 0, 205]
                    continue
                if(tile.AdjecentMines == 7):
                    sense.set_pixel(tile.x, tile.y, [0, 205, 205])
                    tile.vari = [0, 205, 205]
                    continue
                if(tile.AdjecentMines == 8):
                    sense.set_pixel(tile.x, tile.y, [205, 205, 205])
                    tile.vari = [205, 205, 205]
                    continue
                print("Oho")
                continue
            if(tile.status == "hidden"):
                sense.set_pixel(tile.x, tile.y, [50, 50, 50])
                tile.vari = [50, 50, 50]
                continue
            if(tile.status == "marked"):
                sense.set_pixel(tile.x, tile.y, [0, 205, 0])
                tile.vari = [0, 205, 0]
                continue
            if(tile.status == "mine"):
                sense.set_pixel(tile.x, tile.y, [205, 0, 0])
                tile.vari = [205, 0, 0]
                continue
    variarvo = 50
    vari = (board[cursor[0]][cursor[1]].vari[0] + variarvo, board[cursor[0]][cursor[1]].vari[1] + variarvo, board[cursor[0]][cursor[1]].vari[2] + variarvo)
    if HeldMid and board[cursor[0]][cursor[1]].status == "hidden":
        vari = (50, 255, 50)
    sense.set_pixel(cursor[0], cursor[1], vari)

AllScreenUpdate()

PressedMidTime = [0.0, 0.0]

def cursor_move(event) :
    #print(event)
    global HeldMid, PressedMidTime
    global cursor, game
    if event.action in ('pressed'):
        #print("pressed", cursor)
        HeldMid = False
        if(event.direction == 'left') and (cursor[0] > 0):
            cursor[0]-= 1
        if(event.direction == 'right') and (cursor[0] < 7):
            cursor[0]+= 1
        if(event.direction == 'up') and (cursor[1] > 0):
            cursor[1]-= 1
        if(event.direction == 'down') and (cursor[1] < 7):
            cursor[1]+= 1
        if(event.direction == 'middle'):
            print(event.timestamp)
            PressedMidTime.append(event.timestamp)
            PressedMidTime.pop(0)
        return
    
    if event.action in ('held'):
        #print("held", cursor)
        if(event.direction == 'left') and (cursor[0] > 0):
            cursor[0]-= 1
        if(event.direction == 'right') and (cursor[0] < 7):
            cursor[0]+= 1
        if(event.direction == 'up') and (cursor[1] > 0):
            cursor[1]-= 1
        if(event.direction == 'down') and (cursor[1] < 7):
            cursor[1]+= 1
        if(event.direction == 'middle'):
            #print(event.timestamp)
            HeldMid = True
    if event.action in ('released'):
        #print("Released", cursor)
        if HeldMid and game:
            HeldMid = False
            if(board[cursor[0]][cursor[1]].status == "hidden"):
                board[cursor[0]][cursor[1]].status = "marked"
                return
            if(board[cursor[0]][cursor[1]].status == "marked"):
                board[cursor[0]][cursor[1]].status = "hidden"
                return
            if(board[cursor[0]][cursor[1]].status == "number"):
                if isDashingPossible(board[cursor[0]][cursor[1]].AdjecentMines, cursor[0], cursor[1]):
                    Dashing(cursor[0], cursor[1])
                    AllScreenUpdate()
                return
        if((PressedMidTime[1] - PressedMidTime[0]) < 500) and event.direction == 'middle':
            print(PressedMidTime[1] - PressedMidTime[0])
            if(board[cursor[0]][cursor[1]].status == "marked"):
                return
            if(board[cursor[0]][cursor[1]].mine):
                LOSE()
                return
            if(board[cursor[0]][cursor[1]].status == "number"):
                return
            NumberOfMinesTouchingTile(cursor[0], cursor[1], board[cursor[0]][cursor[1]])
            

    AllScreenUpdate()

try:
    sense.stick.direction_up = cursor_move
    sense.stick.direction_down = cursor_move
    sense.stick.direction_left = cursor_move
    sense.stick.direction_right = cursor_move
    sense.stick.direction_middle = cursor_move
    while True:
        if gameEnded:
            sense.stick.direction_up = None
            sense.stick.direction_down = None
            sense.stick.direction_left = None
            sense.stick.direction_right = None
            sense.stick.direction_middle = None
            break
except KeyboardInterrupt:
    print("ohjelma lopetetaan")
finally:
    time.sleep(5)
    sense.clear()
    print("ohjelma lopetetaan")