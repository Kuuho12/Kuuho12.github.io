using System;
using System.Collections.Generic;
using System.Data.Common;
using System.Net;
using System.Reflection.Metadata;
using System.Security.Principal;
                /* ----------------------------------------------------------------------
                Pelasin tätä peliä terminaalissa. Pelin voi tarkoituksellisesti crashätä
                vastaamalla kysymykseen jollakin muulla kuin numerolla, jotta pelistä voi 
                poistua helposti.
                Tämän koodauksessa kesti ihan liian kauan, koska vähän viivyttelin tämän 
                tekemisessä, olen ollut vähän kipeää ja lukio-opinnot ovat alkaneet, mutta
                ensisijaisesti koska tämän koodaamisessa kesti paljon pitempään kuin mitä
                luulin.
                   ---------------------------------------------------------------------- */
namespace ConsoleApp2
{
    class Program
    {
        public static int aikayksikkö = 0;
        public static bool valo = true;
        public static string sijainti = "aloitus1";
        public static string aloitustilanne = "1";
        public static string oikeakäsisisältö = "";
        public static string[] vasenkäsisisältö = {"", "false"};
        public static bool reppumukana = false;
        public static string[] ärraytonpaskoja = {"paristot", "pinni", "tyhjä vesipullo", "puukko"};
        public static List<string> repunsisältö = new List<string>(ärraytonpaskoja); //{"paristot", "pinni", "tyhjä vesipullo", "puukko"};
        public static string aloituskäytäväSuunta = "S";
        public static bool oletkoisossahuoneessa = false;
        public static bool onkovasenpuuoviauki = false;
        public static bool onkometallioviauki = false;
        public static bool onkokirvesotettu = false;
        public static bool onkooikeapuuovirikottu = false;
        public static int yritykset = 3;
        public static bool onkokassakaappikoodiarvattu = false;
        public static bool onkolappulöydetty = false;
        public static bool oletkoeteisessä = false;
        static void Main(string[] args)
        {
            int vastaus = 0;
            Console.WriteLine("Heräät lattialta hämärästä ankeasta ikkunattomasta huoneesta");
            Console.ReadKey();
            Console.WriteLine("Huoneen kulmassa vanha öljylamppu palaa himmeänä ja toisessa kulmassa reppu lojuu lattialla. Huoneen ainoa ovi on raollaan. ");
            Console.ReadKey();
            Console.WriteLine("Tajuat ettet muista miten tänne päädyit tai mikä paikka tämä on");
            Console.ReadKey();
            Console.WriteLine("Mitä teet? 1: Menet ovesta ulos 2: Otat öljylampun 3: Otat repun");
            vastaus = ReadLine_();
            Tapahtuma(vastaus);
            WriteLine_(sijainti);
            while(!(sijainti == "VOITIT") && !(sijainti == "HÄVISIT")) {
                vastaus = ReadLine_();
                aikayksikkö++;
                Tapahtuma(vastaus);
                WriteLine_(sijainti);
            }

        }
        static int ReadLine_()
        {
            if(aikayksikkö<152 && aikayksikkö>149) {
                Console.WriteLine("Tunnet itsesi nälkäiseksi"); Console.ReadKey();
            }
            aikayksikkö++;
            if(aikayksikkö>199) {
                Console.WriteLine("Kuolit nälkään"); Console.ReadKey();
                sijainti="HÄVISIT";
            }
            return Convert.ToInt32(Console.ReadLine());
        }
        static void Tapahtuma(int vastaus) 
        {
            if (vastaus == 0 && !(sijainti=="HÄVISIT")) {
                Console.WriteLine("Oikeakäsi: " + oikeakäsisisältö);
                Console.WriteLine("Vasenkäsi: " + vasenkäsisisältö[0]);
                if (reppumukana) {
                    Console.WriteLine("Repunsisältö:");
                    foreach(string i in repunsisältö) {
                        Console.WriteLine(i);
                    }
                }
                string oikeakäsikysymys;
                if(oikeakäsisisältö=="") {
                    oikeakäsikysymys = "Ottaa oikeaan käteen jotain";
                } else oikeakäsikysymys = "Vaihtaa oikean käden sisältöä";
                Console.WriteLine("Mitä haluat tehdä? 0: Ei yhtää mitään 1: " + oikeakäsikysymys + " 10: Miettiä");
                vastaus = ReadLine_();
                switch(vastaus) {
                    case 0:
                    return;
                    case 10:
                    if((sijainti=="metalliovi" && !onkolappulöydetty) || (sijainti=="isohuone" && !onkolappulöydetty)) {
                        Console.WriteLine("Mietittyäsi tajusit, että huoneen maton alla saattaa olla piilotettu jotakin"); Console.ReadKey();
                        repunsisältö.Add("4578-lappunen");
                        Console.WriteLine("Maton nostettuasi löydät pienen lappusen, johon on kirjoitettu 4578. Otat lappusen"); Console.ReadKey();
                        onkolappulöydetty = true;
                        return;
                    } 
                    if(sijainti=="metallisivuhuone") {
                        Console.WriteLine("Kirjaimet FF kuulostavat tutuilta amisvuosiltasi, mutta et muista miksi ne kuulostavat tutuilta"); Console.ReadKey();
                        return;
                    }
                    if(sijainti=="oikeapuuovi") {
                        Console.WriteLine("Kirves voi tehdä selvää jälkeä tästä ovesta"); Console.ReadKey();
                        return;
                    }
                    Console.WriteLine("Ajatuksesi ovat täynnä kauhakuvia siitä, mitä tämä paikka sisältää ja miten tänne päädyit"); Console.ReadKey();
                    return;
                    case 1:
                    if(!reppumukana) {
                        Console.WriteLine("Sinulla ei ole mitään jota voisit laittaa oikeaan käteesi");
                        Console.ReadKey();
                        return;
                    }
                    string repunsisältöteksti = "Minkä valitset oikeaan käteesi?";
                    for(int j = 0; j < repunsisältö.Count; j++) {
                        repunsisältöteksti+= " " + Convert.ToString(j) + ": " + repunsisältö[j];
                    }
                    Console.WriteLine(repunsisältöteksti);
                    vastaus = ReadLine_();
                    int k = 0;
                    while(k < repunsisältö.Count) {
                        if(k == vastaus) {
                            string reppuun = oikeakäsisisältö;
                            oikeakäsisisältö = repunsisältö[k];
                            if(reppuun=="") {
                                int repunkoko = repunsisältö.Count;
                                string[] repunsisältö2 = new string[repunsisältö.Count-1];
                               int ii = 0;
                                for(int l = 0; l+ii < repunkoko; l++) {
                                    if(k==l) {
                                        ii = 1;
                                    }
                                    repunsisältö2[l] = repunsisältö[l+ii];
   
                                }
                                repunsisältö =new List<string>(repunsisältö2);
                                return;
                            }
                            repunsisältö[k] = reppuun;
                            return;
                            
                        }
                        k++;
                    }
                    return;
                } 
                return;
                
            }
            switch(sijainti) {
                case "aloitus1":
                    switch(vastaus) {
                    case 1:
                    sijainti = "aloituskäytävä";
                    return;
                    case 2:
                    aloitustilanne = "2";
                    sijainti = "aloitus2";
                    vasenkäsisisältö = new string[] {"öljylamppu", "true"};
                    Console.WriteLine("Otit öljylampun vasempaan käteesi"); Console.ReadKey();
                    return;
                    case 3:
                    aloitustilanne = "3";
                    sijainti = "aloitus3";
                    reppumukana = true;
                    Console.WriteLine("Repussa on paristot, pinni, tyhjä vesipullo ja puukko. Laitat repun selkääsi");Console.ReadKey();
                    return;
                    } break;
                case "aloitus2":
                switch(vastaus) {
                    case 1:
                    aloituskäytäväSuunta = "S";
                    sijainti = "aloituskäytävä";
                    return;
                    case 2:
                    aloitustilanne = "4";
                    sijainti = "aloitus4";
                    reppumukana = true;
                    Console.WriteLine("Repussa on paristot, pinni, tyhjä vesipullo ja puukko. Laitat repun selkääsi"); Console.ReadKey();
                    return;
                } break;
                case "aloitus3":
                switch(vastaus) {
                    case 1:
                    aloituskäytäväSuunta = "S";
                    sijainti = "aloituskäytävä";
                    return;
                    case 2:
                    aloitustilanne = "4";
                    sijainti = "aloitus4";
                    return;
                } break;
                case "aloitus4":
                switch(vastaus) {
                    case 1:
                    aloituskäytäväSuunta = "S";
                    sijainti = "aloituskäytävä";
                    return;
                }break;
                case "aloituskäytävä":
                if(ValoisuusCheck()) {
                    switch(vastaus) {
                        case 1:
                        sijainti = "isohuone";
                        return;
                        case 2:
                        aikayksikkö++;
                        sijainti = "eteinen";
                        return;
                        case 3:
                        if(!onkooikeapuuovirikottu) {
                        sijainti = "oikeapuuovi";
                        return;
                        }
                        Console.WriteLine("Saavut huoneeseen, jossa on kassakaappi"); Console.ReadKey();
                        Console.WriteLine("Kaassakaapissa on kolminumeroinen digitaaallinen koodilukko. Näytöllä koodisyötön yläpuolella lukee " + Convert.ToString(yritykset) + " yritystä jäljellä"); Console.ReadKey();
                        sijainti = "oikeahuone";
                        return;
                        case 4:
                        sijainti = "aloitus" + aloitustilanne;
                        return;
                    }
                }
                switch(vastaus) {
                    case 1:
                    sijainti = "HÄVISIT";
                    Console.WriteLine("Eksyit pimeässä");
                    return;
                    case 2:
                    sijainti = "aloitus" + aloitustilanne;
                    return;
                }break;
                case "isohuone":
                switch(vastaus) {
                    case 1:
                    if(onkovasenpuuoviauki) {
                        sijainti="puusivuhuone";
                        return;
                    }
                    sijainti="vasenpuinenovi";
                    return;
                    case 2:
                    if(onkometallioviauki) {
                        sijainti="metallisivuhuone";
                        return;
                    }
                    Console.WriteLine("Ovessa on nelinumeroinen digitaallinen nelinumeroinen koodilukko. Lukon viereen on raapustettu metallipintaan sana Mieti"); Console.ReadKey();
                    sijainti="metalliovi";
                    return;
                    case 3:
                    sijainti="aloituskäytävä";
                    aloituskäytäväSuunta="W";
                    oletkoisossahuoneessa = false;
                    return;
                }break;
                case "vasenpuinenovi":
                switch(vastaus) {
                    case 1:
                    sijainti="isohuone";
                    return;
                    case 2:
                    Console.WriteLine("Kukaan ei vastaa koputukseen."); Console.ReadKey();
                    Console.WriteLine("Ovi vaikutti liian vahvalta lihasvoimin rikottavaksi"); Console.ReadKey();
                    return;
                    case 3:
                    if(oikeakäsisisältö!="pinni") {
                        break;
                    }
                    onkovasenpuuoviauki = true;
                    sijainti="puusivuhuone";
                    Console.WriteLine("Tiirikoit oven näppärästi"); Console.ReadKey();
                    return;
                }break;
                case "metalliovi":
                switch(vastaus) {
                    case 1:
                    sijainti="isohuone";
                    return;
                    case 2:
                    Console.WriteLine("Kukaan ei vastaa koputukseen."); Console.ReadKey();
                    Console.WriteLine("Ovi vaikutti liian vahvalta lihasvoimin rikottavaksi"); Console.ReadKey();
                    return;
                    case 3:
                    Console.WriteLine("Arvaa nelinumeroinen koodi:");
                    vastaus = ReadLine_();
                    if(!(vastaus==4578)) {
                        Console.WriteLine("Arvasit koodin väärin"); Console.ReadKey();
                        return;
                    }
                    onkometallioviauki = true;
                    Console.WriteLine("Arvasit koodin oikein"); Console.ReadKey();
                    sijainti = "metallisivuhuone";
                    return;
                }break;
                case "metallisivuhuone":
                switch(vastaus) {
                    case 1:
                    sijainti="isohuone";
                    return;
                }break;
                case "puusivuhuone":
                switch(vastaus) {
                    case 1:
                    if(!onkokirvesotettu) {
                    repunsisältö.Add("kirves");
                    onkokirvesotettu = true;
                    Console.WriteLine("Otit kirveen"); Console.ReadKey();
                    return;
                    }
                    sijainti="isohuone";
                    return;
                    case 2:
                    sijainti="isohuone";
                    return;
                } break;
                case "oikeapuuovi":
                switch(vastaus) {
                    case 1:
                    aloituskäytäväSuunta = "E";
                    sijainti="aloituskäytävä";
                    return;
                    case 2:
                    Console.WriteLine("Kukaan ei vastaa koputukseen."); Console.ReadKey();
                    Console.WriteLine("Ovi vaikutti liian vahvalta lihasvoimin rikottavaksi"); Console.ReadKey();
                    return;
                    case 3:
                    if(oikeakäsisisältö=="kirves") {
                        onkooikeapuuovirikottu = true;
                        sijainti="oikeahuone";
                        Console.WriteLine("Tuhottuasi oven kirveellä astut huoneeseen, jossa on kassakaappi"); Console.ReadKey();
                        Console.WriteLine("Kaassakaapissa on kolminumeroinen digitaaallinen koodilukko. Näytöllä koodisyötön yläpuolella lukee 3 yritystä jäljellä"); Console.ReadKey();
                        return;
                    }
                    break;
                }break;
                case "oikeahuone":
                switch(vastaus) {
                    case 1:
                    aloituskäytäväSuunta = "E";
                    sijainti="aloituskäytävä";
                    return;
                    case 2:
                    Console.WriteLine("Arvaa kolminumeroinen koodi:");
                    vastaus = ReadLine_();
                    if(!(vastaus==255)) {
                        Console.WriteLine("Arvasit koodin väärin"); Console.ReadKey();
                        yritykset--;
                        Console.WriteLine(Convert.ToString(yritykset) + " yritystä jäjellä"); Console.ReadKey();
                        if(yritykset==0) {
                            sijainti="HÄVISIT";
                        }
                        return;
                    }
                    onkometallioviauki = true;
                    Console.WriteLine("Arvasit koodin oikein"); Console.ReadKey();
                    repunsisältö.Add("paksuavain");
                    Console.WriteLine("Kassakaapissa on iso paksu avain, jonka otat"); Console.ReadKey();
                    return;
                }break;
                case "eteinen":
                switch(vastaus) {
                    case 1:
                    sijainti="aloituskäytävä";
                    aloituskäytäväSuunta = "N";
                    oletkoeteisessä = false;
                    aikayksikkö++;
                    return;
                    case 2:
                    sijainti="eteisenovi";
                    Console.WriteLine("Ovessa on iso paksu lukko"); Console.ReadKey();
                    return;
                    case 3:
                    Console.WriteLine("Verhojen takaa näet ikkunan läpi aurinkoisen soraisen pihan, joka päättyy metsikköön"); Console.ReadKey();
                    return;
                } break;
                case "eteisenovi":
                switch(vastaus) {
                    case 1:
                    sijainti="aloituskäytävä";
                    aloituskäytäväSuunta = "N";
                    oletkoeteisessä = false;
                    aikayksikkö++;
                    return;
                    case 2:
                    Console.WriteLine("Verhojen takaa näet ikkunan läpi aurinkoisen soraisen pihan, joka päättyy metsikköön"); Console.ReadKey();
                    return;
                    case 3:
                    if(oikeakäsisisältö=="pinni") {
                        oikeakäsisisältö="rikkinäinen pinni";
                        Console.WriteLine("Lukko oli liian iso ja paksu pinnillä tiirikoitavaksi, joten väänsit pinnin rikki"); Console.ReadKey();
                        return;
                    }
                    if(oikeakäsisisältö=="paksuavain") {
                        Console.WriteLine("Ovi avautui"); Console.ReadKey();
                        sijainti="VOITIT";
                        return;
                    }
                    break;
                }break;
                case "VOITIT":
                return;
                default:
                Console.WriteLine("Olet kadoksissa."); Console.ReadKey();
                return;
            }
            Console.WriteLine("Vastaa jollakin annetuista vaihtoehdoista tampio"); Console.ReadKey();
            return;
        }
        // |||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||
        static void WriteLine_(string sijainti) {
            switch(sijainti) {
                /*Console.WriteLine("Mitä teet? 1:" + " 0: Jotain muuta"); 
                return; */
                case "eteisenovi":
                if(oikeakäsisisältö=="paksuavain") {
                    Console.WriteLine("Mitä teet? 1: Palaat takaisinpäin 2: Kurkistat verhojen taakse 3: Avaat oven paksulla avaimella 0: Jotain muuta");
                    return;
                }
                if(oikeakäsisisältö=="pinni") {
                    Console.WriteLine("Mitä teet? 1: Palaat takaisinpäin 2: Kurkistat verhojen taakse 3: Yrität tiirikoida oven 0: Jotain muuta");
                    return;
                }
                Console.WriteLine("Mitä teet? 1: Palaat takaisinpäin 2: Kurkistat verhojen taakse 0: Jotain muuta");
                return;
                case "eteinen":
                if(!oletkoeteisessä) {
                    oletkoeteisessä = true;
                    Console.WriteLine("Kävelit pitkän käytävän läpi tilavaan huoneeseen, jonka päädyssä on ovi ja sen kummallakin puolella paksujen verhojen takaa hohtaa valoa"); Console.ReadKey();
                    Console.WriteLine("Mitä teet? 1: Palaat takaisinpäin 2: Menet ovelle 3: Kurkistat verhojen taakse 0: Jotain muuta");
                    return;
                }
                Console.WriteLine("Mitä teet? 1: Palaat takaisinpäin 2: Menet ovelle 3: Kurkistat verhojen taakse 0: Jotain muuta");
                return;
                case "oikeahuone":
                if(!onkokassakaappikoodiarvattu) {
                    Console.WriteLine("Mitä teet? 1: Palaat takaisinpäin 2: Yrität arvata koodin 0: Jotain muuta");
                    return;
                }
                Console.WriteLine("Mitä teet? 1: Palaat takaisinpäin 0: Jotain muuta");
                return;
                case "oikeapuuovi":
                Console.WriteLine("Käytävä päättyy puiseen oveen, joka ei avaudu vaikka ovessa ei lukkoa"); Console.ReadKey();
                if(oikeakäsisisältö=="kirves") {
                    Console.WriteLine("Mitä teet? 1: Palaat takaisinpäin 2: Koputat oveen 3: Rikot oven kirveellä" + " 0: Jotain muuta");
                    return;
                }
                Console.WriteLine("Mitä teet? 1: Palaat takaisinpäin 2: Koputat oveen" + " 0: Jotain muuta");
                return;
                case "metallisivuhuone":
                Console.WriteLine("Huone on tyhjä lukuunottamatta julistetta seinällä, jossa lukee FF"); Console.ReadKey();
                Console.WriteLine("Mitä teet? 1: Poistut huoneesta" + " 0: Jotain muuta");
                return;
                case "puusivuhuone":
                if(!onkokirvesotettu) {
                Console.WriteLine("Huone on täysin tyhjä luukuunottamatta kirvestä maassa"); Console.ReadKey();
                Console.WriteLine("Mitä teet? 1: Otat kirveen 2: Poistut" + " 0: Jotain muuta");
                return;
                }
                Console.WriteLine("Huone on täysin tyhjä"); Console.ReadKey();
                Console.WriteLine("Mitä teet? 1: Poistut" + " 0: Jotain muuta");
                return;
                case "metalliovi":
                Console.WriteLine("Mitä teet? 1: Poistut oven luolta 2: Koputat ovea 3: Yrität arvata koodin" + " 0: Jotain muuta"); 
                return;
                case "vasenpuinenovi":
                Console.WriteLine("Ovi on lukossa, mutta lukko näyttää vanhalta ja helposti tiirikoitavalta"); Console.ReadKey();
                if(oikeakäsisisältö=="pinni") {
                    Console.WriteLine("Mitä teet? 1: Poistut oven luolta 2: Koputat ovea 3: Tiirikoit oven pinnillä" + " 0: Jotain muuta"); 
                    return;
                }
                Console.WriteLine("Mitä teet? 1: Poistut oven luolta 2: Koputat ovea" + " 0: Jotain muuta"); 
                return;
                case "isohuone":
                if(!oletkoisossahuoneessa) {
                Console.WriteLine("Käytävän kääntyessä saavuit isoon huoneeseen, jota koristaa iso matto ja jossa on kaksi ovea, yksi puinen ja yksi metallinen."); Console.ReadKey();
                oletkoisossahuoneessa = true;
                Console.WriteLine("Mitä teet? 1: Menet puiselle ovelle 2: Menet metalliselle ovelle 3: Palaat takaisin käytävää pitkin" + " 0: Jotain muuta"); 
                return;
                } else
                Console.WriteLine("Mitä teet? 1: Menet puiselle ovelle 2: Menet metalliselle ovelle 3: Palaat takaisin käytävää pitkin" + " 0: Jotain muuta"); 
                return;
                case "aloitus1":
                Console.WriteLine("Mitä teet? 1: Menet ovesta ulos 2: Otat öljylampun 3: Otat repun");
                return;
                case "aloitus2":
                Console.WriteLine("Mitä teet? 1: Menet ovesta ulos 2: Otat repun" + " 0: Jotain muuta");
                return;
                case "aloitus3":
                Console.WriteLine("Mitä teet? 1: Menet ovesta ulos 2: Otat öljylampun" + " 0: Jotain muuta");
                return;
                case "aloitus4":
                Console.WriteLine("Mitä teet? 1: Menet ovesta ulos" + " 0: Jotain muuta");
                return;
                case "aloituskäytävä":
                if (ValoisuusCheck()) {
                    switch(aloituskäytäväSuunta) {
                        case "S":
                        Console.WriteLine("Menit ulos käytävään, joka jatkuu vasemmalle, eteenpäin ja oikealle"); Console.ReadKey();
                        Console.WriteLine("Mitä teet? 1: Menet vasemmalle 2: Menet eteenpäin 3: Menet oikealle 4: Palaat takaisin aloitushuoneeseen 0: Jotain muuta");
                        return;
                        case "W":
                        Console.WriteLine("Saavut käytävää pitkin takaisin aloitushuoneen ovelle, josta käytävä jatkuu vasemmalle ja eteenpäin"); Console.ReadKey();
                        Console.WriteLine("Mitä teet? 1: Palaat takaisin isoon huoneeseen 2: Menet vasemmalle 3: Menet eteenpäin 4: Menet aloitushuoneeseen 0: Jotain muuta");
                        return;
                        case "N":
                        Console.WriteLine("Saavut pitkää käytävää pitkin takaisin aloitushuoneen ovelle, josta käytävä jatkuu vasemmalle ja oikealle"); Console.ReadKey();
                        Console.WriteLine("Mitä teet? 1: Menet oikealle 2: Palaat takaisin 3: Menet vasemmalle 4: Menet eteenpäin aloitushuoneeseen 0: Jotain muuta");
                        return;
                        case "E":
                        Console.WriteLine("Saavut käytävää pitkin takaisin aloitushuoneen ovelle, josta käytävä jatkuu eteenpäin ja oikealle"); Console.ReadKey();
                        Console.WriteLine("Mitä teet? 1: Menet eteenpäin 2: Menet oikealle 3: Palaat takaisinpäin 4: Menet vasemmalle aloitushuoneeseen 0: Jotain muuta");
                        return;
                    } break;
                } else
                Console.WriteLine("Menit ovesta ulos pimeään käytävään"); Console.ReadKey();
                Console.WriteLine("Mitä teet? 1: Jatkat sokeasti eteenpäin 2: Palaat takaisin" + " 0: Jotain muuta"); 
                return;
                case "HÄVISIT":
                Console.ReadKey();
                Console.WriteLine("Hävisit pelin.");
                return;
                case "VOITIT":
                Console.WriteLine("Juokset innoissasi ulos vapaaseen maailmaan"); Console.ReadKey();
                Console.WriteLine("Voitit pelin"); Console.ReadKey();
                return;
                default:
                Console.WriteLine("Olet täysin kadoksissa");
                return;

            }
            //return;
        }
        static bool ValoisuusCheck() {
            if (vasenkäsisisältö[1] == "true") {
                valo = true;
                return valo;
            }
            if (sijainti == "aloitus" || sijainti == "aloitus3") {
                valo = true;
                return valo;
            }
            valo = false;
            return valo;
        }
    }
}